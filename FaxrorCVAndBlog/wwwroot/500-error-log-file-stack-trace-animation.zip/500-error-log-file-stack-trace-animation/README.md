# 500 Error:  Log File / Stack Trace Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/quinlo/pen/aajEyb](https://codepen.io/quinlo/pen/aajEyb).

This weeks code-doodle is just a little 500 error page mockup.  Tried to capture the feeling of going through stack traces and lines and lines of log-files in an aesthetically pleasing way. -- wanted to mess around with css variables so likely doesn't work too well in ie :)